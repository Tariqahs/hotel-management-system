
import java.awt.HeadlessException;
import java.security.Timestamp;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Date;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;




public class CustomerList extends javax.swing.JFrame {

    /**
     * Creates new form CustomerList
     */
    public CustomerList() {
        
        initComponents();
        showDetails();
        
        
    }
  private JFrame frame;

  public void showDetails() {
    DefaultTableModel model = (DefaultTableModel) table.getModel();
    Connection con = null;
    PreparedStatement pstmt = null;

    try {
        // Establish database connection
        Class.forName("com.mysql.cj.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hms", "root", "");

        // Retrieve customer and booking details
        String query = "SELECT c.name, c.contact, c.idNumber, b.room, b.number_of_persons FROM customer c "
                     + "LEFT JOIN bookings b ON c.idNumber = b.idNumber";
        pstmt = con.prepareStatement(query);
        ResultSet rs = pstmt.executeQuery();

        // Populate the JTable with retrieved data
        while (rs.next()) {
            String name = rs.getString("name");
            String contact = rs.getString("contact");
            String idNumber = rs.getString("idNumber");
            String room = rs.getString("room");
            String inhabitants = rs.getString("number_of_persons");

            model.addRow(new Object[]{name, contact, idNumber, room, inhabitants});
        }

        // Print the number of rows retrieved
        System.out.println("Number of rows retrieved: " + model.getRowCount());

        rs.close();

    } catch (Exception e) {
        e.printStackTrace(); // Print the stack trace for debugging
        JOptionPane.showMessageDialog(this, "Error occurred: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    } finally {
        // Close resources in the finally block
        try {
            if (pstmt != null) {
                pstmt.close();
            }
            if (con != null) {
                con.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace(); // Print the stack trace for debugging
            System.out.println("Exception closing resources: " + ex);
        }
    }

    // Set the model to the JTable after populating the data
    table.setModel(model);
    // Set the model to the JTable after populating the data
    
}


    // Rest of your generated code...

    // Main method for testing
  
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        table = new javax.swing.JTable();
        btnHome = new javax.swing.JButton();
        btnLogout = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        table.setFont(new java.awt.Font("Monaco", 0, 14)); // NOI18N
        table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Customer Name", "Contact", "ID Number", "Room ID", "Inhabitants"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(table);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(119, 98, 554, 304));

        btnHome.setFont(new java.awt.Font("Monaco", 0, 18)); // NOI18N
        btnHome.setText("Home");
        btnHome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHomeActionPerformed(evt);
            }
        });
        getContentPane().add(btnHome, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 440, 98, 38));

        btnLogout.setFont(new java.awt.Font("Monaco", 0, 18)); // NOI18N
        btnLogout.setText("Logout");
        btnLogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLogoutActionPerformed(evt);
            }
        });
        getContentPane().add(btnLogout, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 440, -1, 35));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/uu.jpg"))); // NOI18N
        jLabel1.setText("jLabel1");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 760, 430));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnHomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHomeActionPerformed
        // TODO add your handling code here:
        new homePage().setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btnHomeActionPerformed

    private void btnLogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLogoutActionPerformed
        // TODO add your handling code here:
        new login().setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btnLogoutActionPerformed

    private void tableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableMouseClicked
        // TODO add your handling code here:
      int row = table.rowAtPoint(evt.getPoint());
String room = (String) table.getValueAt(row, 3);
String idNumber = (String) table.getValueAt(row, 2);

Date date = new Date();
long time = date.getTime();

try {
    Class.forName("com.mysql.cj.jdbc.Driver");
    Connection con;
    con = DriverManager.getConnection("JDBC:mysql://localhost:3306/hms", "root", "");
    PreparedStatement pstmt;
    pstmt = con.prepareStatement("use hms;");
    pstmt.executeUpdate();

    // Use PreparedStatement to prevent SQL injection
    pstmt = con.prepareStatement("SELECT * FROM bookings b JOIN customer c WHERE b.idNumber = c.idNumber AND b.checkout IS NULL AND b.idNumber = ?");
    pstmt.setString(1, idNumber);
    ResultSet rs = pstmt.executeQuery();

    if (rs.next()) {
        String id = rs.getString("booking_id");
        String amount = rs.getString("amount");
        java.sql.Timestamp checkinTimestamp = rs.getTimestamp("checkin");
        long chkin = checkinTimestamp.getTime();
        long bill = Long.parseLong(amount);

        pstmt = con.prepareStatement("SELECT * FROM room WHERE idRoom = ?");
        pstmt.setString(1, room);
        rs = pstmt.executeQuery();

        if (rs.next()) {
            String bobo = rs.getString("price");

            if (bobo != null && bobo.matches("\\d+")) {
                int toto = Integer.parseInt(bobo);
                long div = 1000 * 60 * 60 * 24;
                long days = (time - chkin) / div + 1;
                bill = bill + toto * days;

                int dialogButton = JOptionPane.YES_NO_OPTION;
                int dialogResult = JOptionPane.showConfirmDialog(this, "Bill: " + bill+ "$", "Do you Want to Checkout?", dialogButton);
                if (dialogResult == 0) {
                    pstmt = con.prepareStatement("UPDATE room SET occupied = 0 WHERE idRoom = ?");
                    pstmt.setString(1, room);
                    pstmt.executeUpdate();
                    pstmt = con.prepareStatement("UPDATE bookings SET checkout = ?, amount = ? WHERE booking_id = ?");
                    pstmt.setTimestamp(1, new java.sql.Timestamp(time));
                    pstmt.setLong(2, bill);
                    pstmt.setString(3, id);
                    pstmt.executeUpdate();

                    JOptionPane.showMessageDialog(frame, "Checked Out" , "do you want to print the bill?" , dialogButton);
                    JPanel panel = new JPanel();


// Show the JOptionPane with the custom panel
int result = JOptionPane.showConfirmDialog(frame, panel, "Checked Out", JOptionPane.YES_NO_OPTION);

// Check if the "Print Bill" button was clicked
if (result == JOptionPane.YES_OPTION) {
    // Perform the printing action here (add your printing code)
    System.out.println("Printing bill...");
} else {
    // Handle other cases
}
                    new CustomerList().setVisible(true);
                    this.setVisible(false);
                } else {
                    // Handle other cases
                }
            } else {
                System.out.println("Invalid price format for room: " + room);
            }
        } else {
            System.out.println("Room not found: " + room);
        }
    } else {
        System.out.println("No data found for the given idNumber: " + idNumber);
    }

    con.close();
    pstmt.close();
} catch (SQLException | ClassNotFoundException | NumberFormatException e) {
    System.out.println("Exception: " + e);
}


        
        
    }//GEN-LAST:event_tableMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CustomerList.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CustomerList.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CustomerList.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CustomerList.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        // Create and display the formbtnLogout    
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CustomerList().setVisible(true);
                        

                
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnHome;
    private javax.swing.JButton btnLogout;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable table;
    // End of variables declaration//GEN-END:variables
}
