
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.security.Timestamp;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Date;
import javax.swing.JFrame;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;






public class RoomBooking extends javax.swing.JFrame {
    
    private javax.swing.JLabel NLabel1;
    private javax.swing.JTextField namef;
    private javax.swing.JTextField idNumberf;
    private javax.swing.JTextField contactf;
    private javax.swing.JTextField nationf;
    private javax.swing.JTextField inhabf;
    private javax.swing.JTextField roomf;
    private javax.swing.JLabel IdLabel;
    private javax.swing.JLabel ConLabel;
    private javax.swing.JLabel NatLabel;
    private javax.swing.JLabel NuminLabel;
    private javax.swing.JLabel RoomLabel;
    private javax.swing.JButton btnBook;
    private javax.swing.JLabel AddrLabel;
    private javax.swing.JTextField addressf;
    private javax.swing.JButton btn_Check;
    private javax.swing.JButton btnHome;
    private javax.swing.JTable table;
    private javax.swing.JScrollPane jScrollPane1;
        private javax.swing.JLabel jLabel1;



    /**
     * Creates new form RoomBooking
     */
    public RoomBooking() {
        initComponents();
    }
    private JFrame frame;
    int f=0;
    String PreparedStatement;
    
    
    
    // Example logic in the check button action listener

 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        NLabel1 = new javax.swing.JLabel();
        namef = new javax.swing.JTextField();
        idNumberf = new javax.swing.JTextField();
        contactf = new javax.swing.JTextField();
        nationf = new javax.swing.JTextField();
        inhabf = new javax.swing.JTextField();
        roomf = new javax.swing.JTextField();
        IdLabel = new javax.swing.JLabel();
        ConLabel = new javax.swing.JLabel();
        NatLabel = new javax.swing.JLabel();
        NuminLabel = new javax.swing.JLabel();
        RoomLabel = new javax.swing.JLabel();
        btnBook = new javax.swing.JButton();
        AddrLabel = new javax.swing.JLabel();
        addressf = new javax.swing.JTextField();
        btn_Check = new javax.swing.JButton();
        btnHome = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        NLabel1.setForeground(new java.awt.Color(255, 255, 255));
        NLabel1.setText("Customer name");
        getContentPane().add(NLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(263, 233, -1, -1));

        namef.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                namefActionPerformed(evt);
            }
        });
        getContentPane().add(namef, new org.netbeans.lib.awtextra.AbsoluteConstraints(559, 228, 153, -1));

        idNumberf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                idNumberfActionPerformed(evt);
            }
        });
        getContentPane().add(idNumberf, new org.netbeans.lib.awtextra.AbsoluteConstraints(559, 260, 153, -1));

        contactf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                contactfActionPerformed(evt);
            }
        });
        getContentPane().add(contactf, new org.netbeans.lib.awtextra.AbsoluteConstraints(559, 304, 156, -1));

        nationf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nationfActionPerformed(evt);
            }
        });
        getContentPane().add(nationf, new org.netbeans.lib.awtextra.AbsoluteConstraints(559, 336, 156, -1));
        getContentPane().add(inhabf, new org.netbeans.lib.awtextra.AbsoluteConstraints(559, 373, 156, -1));
        getContentPane().add(roomf, new org.netbeans.lib.awtextra.AbsoluteConstraints(559, 411, 156, -1));

        IdLabel.setForeground(new java.awt.Color(255, 255, 255));
        IdLabel.setText("ID Number");
        getContentPane().add(IdLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(263, 265, -1, -1));

        ConLabel.setForeground(new java.awt.Color(255, 255, 255));
        ConLabel.setText("Contact Number");
        getContentPane().add(ConLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(263, 304, -1, -1));

        NatLabel.setForeground(new java.awt.Color(255, 255, 255));
        NatLabel.setText("Nationality ");
        getContentPane().add(NatLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(263, 341, -1, -1));

        NuminLabel.setForeground(new java.awt.Color(255, 255, 255));
        NuminLabel.setText("Number of Inhabitants");
        getContentPane().add(NuminLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(267, 378, -1, -1));

        RoomLabel.setForeground(new java.awt.Color(255, 255, 255));
        RoomLabel.setText("Room Number ");
        getContentPane().add(RoomLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(267, 416, -1, -1));

        btnBook.setText("Book Room");
        btnBook.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBookActionPerformed(evt);
            }
        });
        getContentPane().add(btnBook, new org.netbeans.lib.awtextra.AbsoluteConstraints(391, 519, -1, -1));

        AddrLabel.setForeground(new java.awt.Color(255, 255, 255));
        AddrLabel.setText("Address");
        getContentPane().add(AddrLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(267, 443, -1, -1));

        addressf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addressfActionPerformed(evt);
            }
        });
        getContentPane().add(addressf, new org.netbeans.lib.awtextra.AbsoluteConstraints(559, 443, 156, -1));

        btn_Check.setText("Check");
        btn_Check.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_CheckActionPerformed(evt);
            }
        });
        getContentPane().add(btn_Check, new org.netbeans.lib.awtextra.AbsoluteConstraints(715, 40, -1, -1));

        btnHome.setText("Home");
        btnHome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHomeActionPerformed(evt);
            }
        });
        getContentPane().add(btnHome, new org.netbeans.lib.awtextra.AbsoluteConstraints(34, 40, -1, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/bobo.jpg"))); // NOI18N
        jLabel1.setText("jLabel1");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1050, 760));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnBookActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBookActionPerformed
        

    btnBook.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
        f = 1; // or f = 2; depending on your logic
    }
    });
   
    Connection con = null;
    PreparedStatement pstmtCustomer = null;
    PreparedStatement pstmtRoom = null;
    PreparedStatement pstmtBooking = null;
        
    try {
        if (f == 8) {
            JOptionPane.showMessageDialog(frame, "Please click the check button");
            return;
        }

        String name = namef.getText();
        String contact = contactf.getText();
        String address = addressf.getText();
        String nation = nationf.getText();
        String idNumber = idNumberf.getText();
        String inhab = inhabf.getText();
        String room = roomf.getText();

        // Check for empty or null values
        if (name.isEmpty() || contact.isEmpty() || address.isEmpty() || nation.isEmpty() || idNumber.isEmpty() || inhab.isEmpty() || room.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Please fill all the details");
            return;
        }

        // Validate contact number and idNumber
        if (!contact.matches("\\d{10}")) {
            JOptionPane.showMessageDialog(frame, "Invalid contact number");
            return;
        }

        if (!idNumber.matches("\\d{10}")) {
            JOptionPane.showMessageDialog(frame, "Invalid idNumber");
            return;
        }

        Date date = new Date();
        long time = date.getTime();

        Class.forName("com.mysql.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hms", "root", "");
        con.setAutoCommit(false);  // Start a transaction

        // Check if the room exists
        String roomQuery = "SELECT * FROM room WHERE idRoom = ?";
        pstmtRoom = con.prepareStatement(roomQuery);
        pstmtRoom.setString(1, room);
        ResultSet rs = pstmtRoom.executeQuery();

        if (rs.next()) {
            int max = rs.getInt("capacity");
            int occ = rs.getInt("occupied");

            if (occ == 1) {
                JOptionPane.showMessageDialog(frame, "Room is already occupied");
                return;
            }

            int inhabs = Integer.parseInt(inhab);

            if (inhabs > max) {
                JOptionPane.showMessageDialog(frame, "Person limit exceeding \nMax " + max);
                return;
            }

            try {
                // Insert customer details
                String insertCustomerQuery = "INSERT INTO customer(idNumber, name, contact, address, nation) VALUES (?, ?, ?, ?, ?)";
                pstmtCustomer = con.prepareStatement(insertCustomerQuery);
                pstmtCustomer.setString(1, idNumber);
                pstmtCustomer.setString(2, name);
                pstmtCustomer.setString(3, contact);
                pstmtCustomer.setString(4, address);
                pstmtCustomer.setString(5, nation);
                pstmtCustomer.executeUpdate();

                // Insert booking details
                String insertBookingQuery = "INSERT INTO bookings(idNumber, number_of_persons, room, checkin) VALUES (?, ?, ?, ?)";
                pstmtBooking = con.prepareStatement(insertBookingQuery);
                pstmtBooking.setString(1, idNumber);
                pstmtBooking.setInt(2, Integer.parseInt(inhab));
                pstmtBooking.setString(3, room);
                pstmtBooking.setTimestamp(4, new java.sql.Timestamp(time));
                pstmtBooking.executeUpdate();

                // Update room occupancy
                String updateRoomQuery = "UPDATE room SET occupied = 1 WHERE idRoom = ?";
                pstmtRoom = con.prepareStatement(updateRoomQuery);
                pstmtRoom.setString(1, room);
                pstmtRoom.executeUpdate();

                con.commit();  // Commit the transaction

                JOptionPane.showMessageDialog(frame, "Room Booked");

                // Replace the following lines with your UI updates or method calls
                new CustomerList().setVisible(true);
                this.setVisible(false);

            } catch (Exception e) {
                // Handle exceptions (e.g., log, display error message)
                System.out.println("Exception: " + e);
                try {
                    if (con != null) {
                        con.rollback();  // Rollback the transaction in case of an exception
                    }
                } catch (SQLException ex) {
                    System.out.println("Rollback Exception: " + ex);
                }
                JOptionPane.showMessageDialog(frame, "Error occurred: " + e.getMessage());

            } finally {
                // Close resources in the finally block
                try {
                    if (pstmtCustomer != null) {
                        pstmtCustomer.close();
                    }
                    if (pstmtRoom != null) {
                        pstmtRoom.close();
                    }
                    if (pstmtBooking != null) {
                        pstmtBooking.close();
                    }
                    // ... (rest of the closing code)
                } catch (SQLException ex) {
                    System.out.println("Exception closing resources: " + ex);
                }
            }
        } else {
            JOptionPane.showMessageDialog(frame, "Invalid room number");
        }
    } catch (Exception e) {
        e.printStackTrace(); // Print the stack trace for debugging
        JOptionPane.showMessageDialog(frame, "Error occurred: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    } finally {
        // Close resources in the finally block
        try {
            if (con != null) {
                con.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace(); // Print the stack trace for debugging
            System.out.println("Exception closing resources: " + ex);
        }
    }





    }//GEN-LAST:event_btnBookActionPerformed

    private void nationfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nationfActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nationfActionPerformed

    private void addressfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addressfActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_addressfActionPerformed

    private void btn_CheckActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_CheckActionPerformed
        // TODO add your handling code here:
        // Example logic in the check button action listener
    

        
        
        
        String idNumber = idNumberf.getText();

// Validate ID number
int l = idNumber.length();
if (l != 10) {
    JOptionPane.showMessageDialog(frame, "ID number is incorrect");
    return;
}

for (int i = 0; i < l; i++) {
    if (idNumber.charAt(i) > '9' || idNumber.charAt(i) < '0') {
        JOptionPane.showMessageDialog(frame, "Invalid ID number");
        return;
    }
}

try {
    Class.forName("com.mysql.jdbc.Driver");
    try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hms", "root","" );
         Statement stmt = con.createStatement()) {

        stmt.executeUpdate("USE hms");

        // Clear text fields
        namef.setText("");

        JOptionPane.showMessageDialog(frame, "ID number verified");

        ResultSet rs = stmt.executeQuery("SELECT * FROM customer WHERE idNumber ='" + idNumber + "';");

        if (rs.next()) {
            // Data found
            String name = rs.getString("name");
            String contact = rs.getString("contact");
            String address = rs.getString("address");
            String nation = rs.getString("nation");

            // Update UI components
            namef.setText(name);
            contactf.setText(contact);
            addressf.setText(address);
            nationf.setText(nation);

            // Set f to 2
            char f = 2;
        } else {
            // No data found
            char f = 1;
        }
    }
} catch (Exception e) {
    System.out.println("Exception: " + e);
}
    }//GEN-LAST:event_btn_CheckActionPerformed

    private void namefActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_namefActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_namefActionPerformed

    private void idNumberfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_idNumberfActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_idNumberfActionPerformed

    private void contactfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_contactfActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_contactfActionPerformed

    private void btnHomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHomeActionPerformed
        // TODO add your handling code here:
         new homePage().setVisible(true);
         this.setVisible(false);
    }//GEN-LAST:event_btnHomeActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(RoomBooking.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(RoomBooking.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(RoomBooking.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(RoomBooking.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new RoomBooking().setVisible(true);
            }
        });
    }
/*
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel AddrLabel;
    private javax.swing.JLabel ConLabel;
    private javax.swing.JLabel IdLabel;
    private javax.swing.JLabel NLabel1;
    private javax.swing.JLabel NatLabel;
    private javax.swing.JLabel NuminLabel;
    private javax.swing.JLabel RoomLabel;
    private javax.swing.JTextField addressf;
    private javax.swing.JButton btnBook;
    private javax.swing.JButton btnHome;
    private javax.swing.JButton btn_Check;
    private javax.swing.JTextField contactf;
    private javax.swing.JTextField idNumberf;
    private javax.swing.JTextField inhabf;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JTextField namef;
    private javax.swing.JTextField nationf;
    private javax.swing.JTextField roomf;
    // End of variables declaration//GEN-END:variables
*/
}

